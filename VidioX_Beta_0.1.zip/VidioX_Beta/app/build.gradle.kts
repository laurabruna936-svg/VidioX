plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.vidiox.beta"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vidiox.beta"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-beta"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.01.00"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.media3:media3-exoplayer:1.6.0")
    implementation("androidx.media3:media3-transformer:1.6.0")
    implementation("androidx.media3:media3-effect:1.6.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
